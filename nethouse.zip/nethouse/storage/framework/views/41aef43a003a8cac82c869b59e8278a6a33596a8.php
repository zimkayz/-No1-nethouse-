
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Table</title>
    <link href="https://fonts.googleapis.com/css?family=Alegreya+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" type="text/css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <style type="text/css">
      h1{
            font-size:30px;
        }
        /*Table Style One*/
        .table .table-header{
            background:#FEC107;
            color:#333;
        }
        .table .table-header .cell{
            padding:20px;
        }
        @media  screen and (max-width: 640px){
            table {
                overflow-x: auto;
                display: block;
            }
            .table .table-header .cell{
                padding:20px 5px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>News Table by ID</h1>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <tr class="table-header">
                  <th class="cell"><a href="<?php echo e(route('new')); ?>">ID</a></th>
                    <th class="cell">Name</th>
                    <th class="cell"><a href="<?php echo e(url('nethouse/3days')); ?>">Text(view latest 3 days news)</a></th>
                    <th class="cell">Created At</th>
                </tr>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  
                    <td><?php echo e($new->id); ?></td>
                    <td><?php echo e($new->name); ?></td>
                    <td><?php echo e($new->text); ?></td>
                    <td><?php echo e(date('jS M Y',strtotime ($new->created_at))); ?></td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
            </table>
        </div>

    </div>
     <div class="d-felx justify-content-center">

            <?php echo e($news->links('pagination::bootstrap-4')); ?>


        </div>
</div>
</body>
</html>

 <?php /**PATH C:\xampp\htdocs\nethouse\resources\views/nethouse/index.blade.php ENDPATH**/ ?>