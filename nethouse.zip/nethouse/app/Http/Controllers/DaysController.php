<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News;
use DB;
use Carbon\Carbon;

class DaysController extends Controller
{
     public function days()
    {
          $news = News::where("created_at",">", Carbon::now()->subDays(3))->latest()->paginate(3);


          return view('nethouse/3days',compact(['news']),['news'=>$news]);



    }

    public function new()
    {
       
          $news = News::all();
         $news = News::latest()->paginate(50);
        return view('nethouse/new',compact(['news']),['news'=>$news]);
    }
}
