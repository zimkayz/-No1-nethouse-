<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Nethouse</title>
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col">

              <div class="card">
                  <div class="card-header">
                   Задание No1 База данных
                  </div>
                  <div class="card-body">
                    <h5 class="card-title">Мы проектируем новый функционал, есть примерная таблица с новостями:
                CREATE TABLE `news` (</h5>
                    
                <ol class="list-group list-group-numbered">
                <li class="list-group-item">`id` int(10) unsigned NOT NULL AUTO_INCREMENT,</li>
                <li class="list-group-item">`name` varchar(255) NOT NULL,</li>
                <li class="list-group-item">`text` TEXT NOT NULL,</li>
                <li class="list-group-item">`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,</li>
                <li class="list-group-item">`deleted_at` datetime DEFAULT NULL,</li>
                <li class="list-group-item">PRIMARY KEY (`id`)</li>
                <li class="list-group-item">) ENGINE=InnoDB DEFAULT CHARSET=utf8;</li>
                </ol>
                <div class="list-group">
                  <p class="list-group-item list-group-item-action list-group-item-primary">
                В таблице планируется до 10 млн записей.</p>
                </div>
                Планируется использовать таблицу следующими способами:
                <ul class="list-group list-group-flush">

                <li class="list-group-item">1. Вывести новость по ID.</li>
                <li class="list-group-item">2. Вывести новости за последние 3 дня.</li>
                <li class="list-group-item">3. Вывести полный список новостей, начиная с самых новых, с разбивкой на
                страницы.</li>
                <li class="list-group-item">Нужно поменять схему таблицы, чтобы она оптимальным образом подходила под
                указанные запросы.</li>
                </ul>
                    <a href="{{url('nethouse/index')}}" class="btn btn-primary">задача выполнена</a>
                  </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>